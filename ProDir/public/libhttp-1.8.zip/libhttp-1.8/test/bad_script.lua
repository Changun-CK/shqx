bad_script 
