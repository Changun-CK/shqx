/* APUE code examples .
 * :copyright: (c) 2016 by the huaxz1986@163.com.
 * :license: lgpl-3.0, see LICENSE for more details.
 */

/*
 *   第十一章：线程
 *
 * 测试 pthread_join 函数的用法
 *
 */
#ifndef THREAD_JOIN
#define THREAD_JOIN

/*!
 * \brief test_thread_join :测试 pthread_join 函数的用法
 */
void test_thread_join();
#endif // THREAD_JOIN

