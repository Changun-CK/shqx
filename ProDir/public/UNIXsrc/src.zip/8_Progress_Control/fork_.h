/* APUE code examples .
 * :copyright: (c) 2016 by the huaxz1986@163.com.
 * :license: lgpl-3.0, see LICENSE for more details.
 */

/*
 *   第八章：进程环境
 *
 * 测试 fork 函数的用法
 *
 */
#ifndef FORK_
#define FORK_
/*!
 * \brief test_fork :测试 fork 函数
 */
void test_fork();


#endif // FORK_

